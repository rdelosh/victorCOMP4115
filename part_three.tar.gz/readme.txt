
Use the following line in order to execute queries.sql:
source queries.sql
The queries found in queries.sql will accopmlish the following task in the following order:
1.Find out the customer who has ordered the most.
2.Find out what is the most ordered item.
3.Find out the total revenue of year 2005
4.Locate all the employees who work in Boston.
5.Find out all the employees who report to the Sales Manager (APAC.)
6.Find out the status of all orders and count how many of each.
7.List how many customers per each different country.
8.Find out how many people possess different job titles and what each title is.
