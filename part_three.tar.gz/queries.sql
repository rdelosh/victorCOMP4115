use classicmodels;

select customername as NumberOne_Customer from customers where customernumber in (select customernumber from payments where amount in ( select max(amount) from payments));

select productname as The_Most_ordered_item from products where productcode in (select productcode from orderdetails where quantityordered in (select max(quantityordered) from orderdetails));

select sum(amount) as Reveneue2005 from payments where paymentDate < '2006-00-00' and paymentDate > '2005-00-00';


select firstname as firstname_BOSTON, lastname as lastname_BOSTON from employees where officecode in (select officecode from offices where officecode in (select officecode from offices where city = 'Boston'));

select firstname as firstname_reportstoSalesManager, lastname as lastname_reportstoSalesManager from employees where reportsto in (select employeenumber from employees where jobtitle = 'sales manager (APAC)');

select status, count(status) from orders group by status order by count(status) desc;

select country, count(country) as custcount_by_country from customers group by country order by count(country) desc;

select jobtitle, count(jobtitle) from employees group by jobtitle order by count(jobtitle) asc;



